//Debug statement used by DebugTracer
#define DEBUG

using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using Microsoft.SharePoint;

using Eversheds.Common.Config;
using Eversheds.Common.Log;
using Eversheds.Common.SharePoint;
using Eversheds.Common.DebugTracer;

namespace Eversheds.SharePoint.KnowledgeSubmissions.Features.Knowledge_Submission
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("f81ce1ea-46a6-4d1f-9666-b9e8a000db83")]
    public class Knowledge_SubmissionEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            DebugTracer trc = new DebugTracer();

            //Get the parent web
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                SPList knowItems = web.Lists["Knowledge Items"];
                SPList knowItemsRej = web.Lists["Knowledge Items Rejected"];

                //Add Items to the Knowledge Parameters List
                //------------------------------------------
                /*
                try
                {
                    SPListItem refCode = web.Lists["Knowledge Parameters"].Items.Add();
                    refCode["Title"] = "Reference Code Counter";
                    refCode["Value"] = "0";
                    refCode.Update();

                    trc.LogInfo("Added 'Ref Code Counter' to the Knowledge Parameters List");


                    SPListItem submitLibrary = web.Lists["Knowledge Parameters"].Items.Add();
                    submitLibrary["Title"] = "Submitted Items Library URL";
                    submitLibrary["Value"] = "KnowledgeItemsList";
                    submitLibrary.Update();

                    trc.LogInfo("Added 'Submitted Items Library URL' to the Knowledge Parameters List");


                    SPListItem rejectLibrary = web.Lists["Knowledge Parameters"].Items.Add();
                    rejectLibrary["Title"] = "Rejected Items Library URL";
                    rejectLibrary["Value"] = "KnowledgeItemsListRejected";
                    rejectLibrary.Update();

                    trc.LogInfo("Added 'Rejected Items Library URL' to the Knowledge Parameters List");


                    SPListItem releaseLibrary = web.Lists["Knowledge Parameters"].Items.Add();
                    releaseLibrary["Title"] = "Release Library";
                    releaseLibrary["Value"] = "Knowledge";
                    releaseLibrary.Update();

                    trc.LogInfo("Added 'Release Library' to the Knowledge Parameters List");


                    SPListItem ctType = web.Lists["Knowledge Parameters"].Items.Add();
                    ctType["Title"] = "Release Content Type";
                    ctType["Value"] = "Eversheds Document";
                    ctType.Update();

                    trc.LogInfo("Added 'Release Content Type' to the Knowledge Parameters List");


                    SPListItem releaseImage = web.Lists["Knowledge Parameters"].Items.Add();
                    releaseImage["Title"] = "Release Site Image";
                    releaseImage["Value"] = "~/_layouts/images/Eversheds/KnowSub/treeViewStar.gif";
                    releaseImage.Update();

                    trc.LogInfo("Added 'Release Site Image' to the Knowledge Parameters List");

                    trc.LogInfo("---- Completed updating Knowledge Parameters List ----");


                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception adding items to Knowledge Parameters List: " + ex.Message);
                }


                //Add items to the Mail Settings List
                //-----------------------------------
                try
                {
                    //Add item for "receive item" to Mail Settings list
                    SPListItem receiveMailSettings = web.Lists["Knowledge Mail Settings"].Items.Add();
                    receiveMailSettings["Title"] = "Receive Item";
                    receiveMailSettings["From Address"] = "Knowledge-ItemReceived@eversheds.com";
                    receiveMailSettings["Cc Address"] = "";
                    receiveMailSettings["Subject"] = "Re: Knowledge submission '[[NAME]]' - reference number: [[REFCODE]]";

                    StringBuilder receiveBody = new StringBuilder();
                    receiveBody.Append("<br />\r\nThank you for your knowledge contribution which will be reviewed by the Knowledge team. You will be alerted within 48 hours whether your item has been approved for publication.<br /><br />\r\n\r\n");
                    receiveBody.Append("Please do not respond to this auto-generated e-mail.<br /><br />\r\n\r\n");
                    receiveBody.Append("Regards,<br /><br />\r\n\r\n");
                    receiveBody.Append("Knowledge@eversheds.com<br />\r\n");

                    receiveMailSettings["Body"] = receiveBody.ToString();
                    receiveMailSettings.Update();

                    trc.LogInfo("Added 'Receive Item' to the Knowledge Mail Settings");


                    //Add item for "release item" to Mail Settings list
                    SPListItem releaseMailSettings = web.Lists["Knowledge Mail Settings"].Items.Add();
                    releaseMailSettings["Title"] = "Release Item";
                    releaseMailSettings["From Address"] = "Knowledge-ItemReleased@eversheds.com";
                    releaseMailSettings["Cc Address"] = "";
                    releaseMailSettings["Subject"] = "Re: Knowledge submission '[[NAME]]' - reference number: [[REFCODE]]";

                    StringBuilder releaseBody = new StringBuilder();
                    releaseBody.Append("<br />\r\nThe item '[[NAME]]' you submitted as knowledge for the Eversheds intranet has now been released.<br /><br />\r\n\r\n");
                    releaseBody.Append("This item has been released to the Knowledge library contained on the [[RELEASESITENAME]] ([[RELEASESITEURL]]).  After final approval from this site's content approvers, the item will be available for use on the intranet.<br /><br />\r\n\r\n");
                    releaseBody.Append("Please do not respond to this auto-generated e-mail.<br /><br />\r\n\r\n");
                    releaseBody.Append("Kind Regards,<br /><br />\r\n\r\n");
                    releaseBody.Append("Knowledge@eversheds.com<br /><br />\r\n\r\n");

                    releaseMailSettings["Body"] = releaseBody.ToString();
                    releaseMailSettings.Update();

                    trc.LogInfo("Added 'Release Item' to the Knowledge Mail Settings");


                    //Add item for "reject item" to Mail Settings list
                    SPListItem rejectMailSettings = web.Lists["Knowledge Mail Settings"].Items.Add();
                    rejectMailSettings["Title"] = "Reject Item";
                    rejectMailSettings["From Address"] = "Knowledge-ItemRejected@eversheds.com";
                    rejectMailSettings["Cc Address"] = "";
                    rejectMailSettings["Subject"] = "Re: Knowledge submission '[[NAME]]' - reference number: [[REFCODE]]";

                    StringBuilder rejectBody = new StringBuilder();
                    rejectBody.Append("<br />\r\nThank you for your  knowledge  submission.  After consideration by [[ENTER PL/CONTENTEDITOR NAME]] your item has been rejected due to [[ENTER REASON e.g. duplication, not deemed to be suitable, client confidentality reasons ]]<br /><br />\r\n\r\n");
                    rejectBody.Append("Please contact [[ENTER NAME]] if you have any further queries (no replies to this auto-generated email will be received). <br /><br />\r\n\r\n");
                    rejectBody.Append("Kind Regards,<br /><br />\r\n\r\n");
                    rejectBody.Append("Knowledge@eversheds.com<br /><br />\r\n\r\n");

                    rejectMailSettings["Body"] = rejectBody.ToString();
                    rejectMailSettings.Update();

                    trc.LogInfo("Added 'Reject Item' to the Knowledge Mail Settings");


                    //Add item for "review item" to Mail Settings list
                    SPListItem reviewMailSettings = web.Lists["Knowledge Mail Settings"].Items.Add();
                    reviewMailSettings["Title"] = "Review Item";
                    reviewMailSettings["From Address"] = "Knowledge-ReviewItem@eversheds.com";
                    reviewMailSettings["Cc Address"] = "";
                    reviewMailSettings["Subject"] = "Knowledge submission '[[NAME]]' - reference number [[REFCODE]]";

                    StringBuilder reviewBody = new StringBuilder();
                    reviewBody.Append("<br />\r\nThe attached item has been received as a knowledge submission. Please would you review this item and confirm that it is suitable for inclusion as knowledge on the Insite intranet. IKS will carry out the necessary sanitising and tagging.<br /><br />\r\n\r\n");
                    reviewBody.Append("The document can be viewed by clicking this link: [[DOCUMENT]]<br /><br />\r\n\r\n");
                    reviewBody.Append("It's metadata can be viewed by clicking this link: [[PROPERTIES]]<br /><br />\r\n\r\n");
                    reviewBody.Append("If you think the item isn't suitable for publishing on the intranet, please let me know with an email to [[ENTER EMAIL ADDRESS]] and I'll contact the submitter (no replies to this auto-generated email will be received).<br /><br />\r\n\r\n");
                    reviewBody.Append("Kind Regards,<br /><br />\r\n\r\n");
                    reviewBody.Append("Knowledge@eversheds.com<br /><br />\r\n\r\n");

                    reviewMailSettings["Body"] = reviewBody.ToString();
                    reviewMailSettings.Update();

                    trc.LogInfo("Added 'Review Item' to the Knowledge Mail Settings");

                    trc.LogInfo("---- Completed updating Knowledge Mail Settings ----");
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception adding items to Mail Settings List: " + ex.Message);
                }


                */


                //Set Event Handlers
                //------------------
                try
                {
                    //Set the email rec'd event handler against Knowledge Items library

                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "setting event handler");


                    string assm = "Eversheds.SharePoint.KnowledgeSubmissions, Version=1.0.0.0, Culture=neutral, PublicKeyToken=bcad62fc0b82cb23";

                    //string nsp = "Eversheds.SharePoint.KnowledgeSubmissions.EventHandlers";
                    string clsName = "Eversheds.SharePoint.KnowledgeSubmissions.EmailHandler.EmailHandler";
                    //knowItems = web.Lists["Knowledge It"];


                    knowItems.EventReceivers.Add(SPEventReceiverType.EmailReceived, assm, clsName);
                    knowItems.Update();


                    trc.LogInfo("---- Completed binding Event Handlers ----");
                }
                catch (Exception ex)
                {
                    trc.LogInfo("Error binding " + ex.Message);
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception setting Event Handlers: " + ex.Message);
                }


                //Email Enable the Knowledge Items list
                //-------------------------------------
                try
                {
                    knowItems.EnableAssignToEmail = true;
                    knowItems.EmailAlias = "Knowledge_Submission";
                    knowItems.Update();

                    knowItems.RootFolder.Properties["vti_emailsaveoriginal"] = "1";             //save orig email
                    knowItems.RootFolder.Properties["vti_emailusesecurity"] = "0";              //allow any user to email items
                    knowItems.RootFolder.Properties["vti_emailattachmentfolders"] = "root";     //save email and attachments in root folder
                    knowItems.RootFolder.Properties["vti_emailoverwrite"] = "0";                //prevent existing items being overwritten
                    knowItems.RootFolder.Update();

                    trc.LogInfo("---- Completed email-enabling Knowledge Items library ----");
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception email enabling Knowledge Items List: " + ex.Message);
                }


                //Turn on Versioning
                //------------------
                try
                {
                    knowItems.EnableVersioning = true;
                    knowItems.MajorVersionLimit = 10;

                    trc.LogInfo("---- Versioning enabled on Knowledge Items library ----");
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception enabling major versioning Knowledge Items List: " + ex.Message);
                }


                //Configure Folders
                //-----------------
                try
                {
                    //Turn Folder Creation On
                    knowItems.EnableFolderCreation = true;
                    knowItems.Update();

                    trc.LogInfo("Enabled Folder creation from 'New' menu");


                    //Created root folders for Knowledge Lib
                    knowItems.RootFolder.SubFolders.Add("KnowledgeMails");
                    knowItems.Update();

                    trc.LogInfo("Created Knowledge E-Mails folder");


                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception creating folder in Knowledge Parameters List: " + ex.Message);
                }


                //Apply Content Type against Knowledge Items & Knowledge Items Rejected
                //----------------------------------------------------------------------
                /*
                try
                {
                    //Remove Document Content Type
                    SPContentType docCt = knowItems.ContentTypes["Document"];
                    knowItems.ContentTypes.Delete(docCt.Id);

                    trc.LogInfo("Removed Document Content Type from Knowledge Items List");


                    //Add Eversheds.Document Content Type
                    SPContentType ct = web.Site.RootWeb.ContentTypes["Eversheds Document"];

                    knowItems.ContentTypesEnabled = true;
                    knowItems.ContentTypes.Add(ct);

                    trc.LogInfo("Applied Eversheds Document content type to Knowledge Items folder");

                    knowItemsRej.ContentTypesEnabled = true;
                    knowItemsRej.ContentTypes.Add(ct);

                    trc.LogInfo("Applied Eversheds Document content type to Knowledge Items Rejected folder");

                    trc.LogInfo("---- Completed configuring Content Types ----");
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception configuring content types: " + ex.Message);
                }

                //-------------------------
                try
                {
                    SPViewCollection views = knowItems.Views;
                    SPViewCollection rejViews = knowItemsRej.Views;

                    StringCollection knowItemsViewFields = new StringCollection();

                    //Ordered by Date Modified
                    knowItemsViewFields.Add("DocIcon");
                    knowItemsViewFields.Add("Modified");
                    knowItemsViewFields.Add("Item_x0020_Title");
                    knowItemsViewFields.Add("Item_x0020_Author");
                    knowItemsViewFields.Add("LinkFilename");
                    knowItemsViewFields.Add("Group1");
                    knowItemsViewFields.Add("Modified_x0020_By");

                    string qry = "<OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy><GroupBy Collapse = \"TRUE\"><FieldRef Name='Status' /></GroupBy>";
                    views.Add("Ordered by Date Modified", knowItemsViewFields, qry, 100, true, false);

                    qry = "<OrderBy><FieldRef Name='Modified' Ascending='False' /></OrderBy>";
                    rejViews.Add("Ordered by Date Modified", knowItemsViewFields, qry, 100, true, false);

                    trc.LogInfo("Created view 'Ordered by Date Modified'");


                    //Ordered by Reference number
                    knowItemsViewFields.Clear();
                    knowItemsViewFields.Add("DocIcon");
                    knowItemsViewFields.Add("Reference_x0020_Code");
                    knowItemsViewFields.Add("Item_x0020_Title");
                    knowItemsViewFields.Add("Item_x0020_Author");
                    knowItemsViewFields.Add("LinkFilename");
                    knowItemsViewFields.Add("Modified");
                    knowItemsViewFields.Add("Group1");
                    knowItemsViewFields.Add("Modified_x0020_By");

                    qry = "<OrderBy><FieldRef Name='Reference_x0020_Code' Ascending='False' /></OrderBy><GroupBy Collapse = \"TRUE\"><FieldRef Name='Status' /></GroupBy>";
                    views.Add("Ordered by Reference Number", knowItemsViewFields, qry, 100, true, true);

                    qry = "<OrderBy><FieldRef Name='Reference_x0020_Code' Ascending='False' /></OrderBy>";
                    rejViews.Add("Ordered by Reference Number", knowItemsViewFields, qry, 100, true, true);

                    trc.LogInfo("Created view 'Ordered by Reference Number'");


                    // Ordered by Item Author
                    knowItemsViewFields.Clear();
                    knowItemsViewFields.Add("DocIcon");
                    knowItemsViewFields.Add("Item_x0020_Author");
                    knowItemsViewFields.Add("Item_x0020_Title");
                    knowItemsViewFields.Add("LinkFilename");
                    knowItemsViewFields.Add("Modified");
                    knowItemsViewFields.Add("Group1");
                    knowItemsViewFields.Add("Modified_x0020_By");

                    qry = "<OrderBy><FieldRef Name='Item_x0020_Author' Ascending='True' /><FieldRef Name='Modified' Ascending='False' /></OrderBy><GroupBy Collapse = \"TRUE\"><FieldRef Name='Status' /></GroupBy>";
                    views.Add("Ordered by Item Author", knowItemsViewFields, qry, 100, true, false);

                    qry = "<OrderBy><FieldRef Name='Item_x0020_Author' Ascending='True' /><FieldRef Name='Modified' Ascending='False' /></OrderBy>";
                    rejViews.Add("Ordered by Item Author", knowItemsViewFields, qry, 100, true, false);

                    trc.LogInfo("Created view 'Ordered by Item Author'");


                    //Ordered by Group
                    knowItemsViewFields.Clear();
                    knowItemsViewFields.Add("DocIcon");
                    knowItemsViewFields.Add("Item_x0020_Author");
                    knowItemsViewFields.Add("Item_x0020_Title");
                    knowItemsViewFields.Add("LinkFilename");
                    knowItemsViewFields.Add("Modified");
                    knowItemsViewFields.Add("Group1");
                    knowItemsViewFields.Add("Modified_x0020_By");

                    qry = "<OrderBy><FieldRef Name='Group1' Ascending='True' /><FieldRef Name='Modified' Ascending='False' /></OrderBy><GroupBy Collapse = \"TRUE\"><FieldRef Name='Status' /></GroupBy>";
                    views.Add("Ordered by Group", knowItemsViewFields, qry, 100, true, false);

                    qry = "<OrderBy><FieldRef Name='Group1' Ascending='True' /><FieldRef Name='Modified' Ascending='False' /></OrderBy>";
                    rejViews.Add("Ordered by Group", knowItemsViewFields, qry, 100, true, false);

                    trc.LogInfo("Created view 'Ordered by Group'");


                    trc.LogInfo("Removed unwanted views from libraries");

                    knowItems.Update();
                    knowItemsRej.Update();

                    trc.LogInfo("---- Completed configuring Views ----");

                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Activate Feature - Exception configuring library views: " + ex.Message);
                    trc.LogInfo("Error creating views " + ex.Message);
                }

                */
                //Cleanup
                trc.Dispose();
            }
        }

        /// <summary>
        /// Code executes when the Knowledge Submissions feature is deactivated,
        /// deletes instances of the list templates and all content within.
        /// </summary>
        /// <param name="properties">Feature reciever properties</param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            DebugTracer trc = new DebugTracer();

            //Get the parent web
            /*
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                try
                {
                    //Delete Knowledge Items list
                    web.Lists["Knowledge Items"].Delete();

                    //Delete Rejected Knowledge Items list
                    web.Lists["Knowledge Items Rejected"].Delete();

                    //Delete Reject Knowledge Mail Settings list
                    web.Lists["Knowledge Mail Settings"].Delete();

                    //Delete Knowledge Parameters list
                    web.Lists["Knowledge Parameters"].Delete();
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Exception deactivating feature: " + ex.Message);
                }
            }
            */
            //Cleanup
            trc.Dispose();
        }

        /// <summary>
        /// Code executes when feature is installed on farm.
        /// </summary>
        /// <param name="properties">Feature Receiver properties.</param>
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
            return;
        }

        /// <summary>
        /// Code executes when feature is uninstalled from farm.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            return;
        }
    }
}

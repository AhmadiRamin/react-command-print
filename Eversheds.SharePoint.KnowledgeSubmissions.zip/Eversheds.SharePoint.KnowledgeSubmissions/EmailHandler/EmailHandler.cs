﻿//Debug statement used by DebugTracer
#define DEBUG

using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using System;
using System.Security.Permissions;
using Eversheds.Common.DebugTracer;
using Eversheds.Common.Email;
using Eversheds.Common.FileSystem;
using Eversheds.Common.Log;
using Eversheds.Common.StringAndText;
using Eversheds.Common.SharePoint;
using System.Web.Configuration;
using System.Data;
using System.IO;
using System.Diagnostics;
using System.Net.Mail;
using System.Configuration;

namespace Eversheds.SharePoint.KnowledgeSubmissions.EmailHandler
{
    /// <summary>
    /// List Email Events
    /// </summary>
    public class EmailHandler : SPEmailEventReceiver
    {

        public override void EmailReceived(SPList list, Microsoft.SharePoint.Utilities.SPEmailMessage emailMessage, string receiverData)
        {
            DebugTracer trc = new DebugTracer();
            trc.LogInfo("Sent item rec'd email.");
            LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Release Knowledge Item]Started");

            try
            {
                //Add EML to doc lib
                //------------------
                //Get the file collection to add email and attachments to
                SPWeb parentWeb = list.ParentWeb;
                SPFileCollection targetFiles = parentWeb.Folders[parentWeb.Url + "/KnowledgeItemsList"].Files;
                parentWeb.AllowUnsafeUpdates = true;
                SPFieldCollection colFields = parentWeb.Lists["Knowledge Items"].Fields;

                Debug.WriteLine("Checking for submitter value");
                Submitter submitterTester = new Submitter();
                //submitterTester.AddCustomField(parentWeb, "Text", "Submitter", false, "", "Eversheds");

                submitterTester.AddFieldToList(colFields, "Submitter");


                //Get the reference number to apply against email and attachments
                SPList parameters = parentWeb.Lists["Knowledge Parameters"];

                //Get the content Type to be used
                SPListItem ctItem = SPListHelper.GetListItem(parameters, "Release Content Type");
                SPContentType ct = list.ContentTypes[ctItem["Value"].ToString()];

                //Debug
                trc.LogInfo("Set default objects.");

                //Add the email to the list as a .EML file
                byte[] message = FileSystemHelper.ReadStreamIntoByteArray(emailMessage.GetMessageStream(), 0);
                string emailFileName = StringHelper.CleanStringOfInvalidChars(emailMessage.Headers["Subject"].ToString());

                //Trim filename length to 80 to fit in with Sharepoints file and URL length restrictions
                if (emailFileName.Length == 0)
                {
                    emailFileName = "No subject";
                }
                else if (emailFileName.Length > 80)
                {
                    emailFileName = emailFileName.Substring(0, 80);
                }
                SPFile emailFile = targetFiles.Add(parentWeb.Url + "/KnowledgeItemsList/" + emailFileName + ".eml", message, true);

                //Debug
                trc.LogInfo("Added email to library as *.EML file: " + emailFile.Name + ".");

                //Set the content type on the email
                emailFile.Item["ContentTypeId"] = ct.Id;
                emailFile.Item.SystemUpdate(false);

                //Debug
                trc.LogInfo("Set content type: " + ct.Name + ".");

                //Set field values
                emailFile.Item["Item_x0020_Title"] = "Email Message";
                emailFile.Item["Item_x0020_Author"] = emailMessage.EnvelopeSender;
                emailFile.Item["Authored_x0020_Date"] = DateTime.Now;
                emailFile.Item["Published_x0020_Date"] = DateTime.Now;
                emailFile.Item["Item_x0020_Review_x0020_Date"] = DateTime.Now.AddYears(1);
                emailFile.Item["Expiry_x0020_Date"] = DateTime.Now.AddYears(2);
                emailFile.Item["Status"] = "Unprocessed";

                //Debug
                trc.LogInfo("Set email field values.");

                //Get Reference Number
                SPListItem refNo = SPListHelper.GetListItem(parameters, "Reference Code Counter");
                int newRef = Convert.ToInt32(refNo["Value"].ToString()) + 1;

                //Increment ref code in params list
                refNo["Value"] = newRef.ToString();
                refNo.SystemUpdate(false);

                //Debug
                trc.LogInfo("Set ref no: " + newRef.ToString() + "values.");

                //Set the value for the thankyou email
                //  string emailRefNo = newRef.ToString("D7") + "-[Attachment Number]";
                string emailRefNo = newRef.ToString();

                emailFile.Item["Reference_x0020_Code"] = newRef.ToString("D7") + "-000";
                emailRefNo = emailFile.Item["Reference_x0020_Code"].ToString();
                emailFile.Item.SystemUpdate(false);

                //Debug
                trc.LogInfo("Set *.EML content type and field values, reference number: " + newRef.ToString("D7") + "-000.");

                //Add email attachements to Doc Lib
                //---------------------------------
                int attachmentCount = 0;
                int intFileCount = 0;
                foreach (SPEmailAttachment emailAttachment in emailMessage.Attachments)
                {
                    //Increment counter
                    attachmentCount++;

                    //Add the file to the list
                    byte[] attachment = FileSystemHelper.ReadStreamIntoByteArray(emailAttachment.ContentStream, 0);
                    string attachmentFileName = StringHelper.CleanStringOfInvalidChars(emailAttachment.FileName);

                    //Trim filename lengt to fit in with Sharepoints file and URL length restrictions

                    if (attachmentFileName.Length > 128)
                    {
                        attachmentFileName = shortenFileName(attachmentFileName);
                    }

                    string fileURL = parentWeb.Url + "/KnowledgeItemsList/" + attachmentFileName;
                    if (fileURL.Length > 260)
                        fileURL = shorten(fileURL);


                    SPFile fileExists = parentWeb.GetFile(fileURL);
                    SPFile attachmentFile = null;
                    // CheckForFile(parentWeb, attachmentFileName, targetFiles);

                    intFileCount = CheckForFile(attachmentFileName, targetFiles);

                    if (intFileCount > 0)
                    {
                        Debug.WriteLine("File exists");
                        Debug.WriteLine(fileURL);
                        string ext = Path.GetExtension(fileURL);
                        fileURL = fileURL.Replace(ext, "_" + intFileCount.ToString() + ext);
                        Debug.WriteLine("New filename" + fileURL);
                        attachmentFile = targetFiles.Add(fileURL, attachment);
                        //trc.LogInfo("Added attachment to library: " + attachmentFile.Name + ".");

                    }
                    else
                    {
                        Debug.WriteLine("File DOES NOT EXIST");
                        attachmentFile = targetFiles.Add(fileURL, attachment);
                    }
                    //Debug


                    //Set the content type on the file
                    attachmentFile.Item["ContentTypeId"] = ct.Id;
                    attachmentFile.Item.SystemUpdate(false);
                    SPPrincipalInfo userInfo = SPUtility.ResolvePrincipal(parentWeb, emailMessage.Sender, SPPrincipalType.User, SPPrincipalSource.All, null, true);
                    //string username = new SPFieldUserValue(parentWeb,

                    SPUser user = parentWeb.AllUsers[userInfo.LoginName];


                    if (intFileCount > 0)
                    {

                        string[] emailname = emailFile.Item["Name"].ToString().Split('.');
                        emailFile.Item["Name"] = string.Format("{0}_{1}.{2}", emailname[0], intFileCount.ToString(), emailname[1]);
                        emailFile.Item.SystemUpdate();
                    }


                    attachmentFile.Item["Submitter"] = userInfo.DisplayName;
                    //Set field values
                    attachmentFile.Item["Reference_x0020_Code"] = newRef.ToString("D7") + "-" + attachmentCount.ToString("D3");
                    attachmentFile.Item["Authored_x0020_Date"] = DateTime.Now;
                    attachmentFile.Item["Published_x0020_Date"] = DateTime.Now;
                    attachmentFile.Item["Item_x0020_Review_x0020_Date"] = DateTime.Now.AddYears(1);
                    attachmentFile.Item["Expiry_x0020_Date"] = DateTime.Now.AddYears(2);
                    attachmentFile.Item["Status"] = "Unprocessed";

                    attachmentFile.Item.SystemUpdate(false);

                    //Increment ref code in params list
                    refNo["Value"] = newRef.ToString();
                    refNo.SystemUpdate(false);

                    //Debug
                    trc.LogInfo("Set attachment content type and field values, reference number: " + newRef.ToString("D7") + "-" + attachmentCount.ToString("D3"));
                }

                //Send Thankyou email
                //-------------------            
                //Get the "To:" address from eml
                string ToAddress = emailMessage.EnvelopeSender;

                SPList emailSettings = parentWeb.Lists["Knowledge Mail Settings"];
                SPListItem mailItem = SPListHelper.GetListItem(emailSettings, "Receive Item");

                string body = mailItem["Body"].ToString();
                body = body.Replace("[[REFCODE]]", emailRefNo);

                string subj;


                subj = mailItem["Subject"].ToString();
                subj = subj.Replace("[[NAME]]", emailMessage.Headers["subject"]);
                subj = subj.Replace("[[REFCODE]]", emailRefNo);

                //Create Email
                MailMessage email = new MailMessage(mailItem["From Address"].ToString(), ToAddress, subj, body);
                email.IsBodyHtml = true;

                //Send the email - have hardcoded this SMTP address here as the OWSTIMER.EXE service
                //(which runs this handler) does not use the web.config as its config file

                //Replace to get to work in vm
                string smtpServer = "SMTP.Eversheds";
                // smtpServer = "domain.dev.local";


                Configuration _Config;

                using (SPWeb web = list.ParentWeb)
                {


                    _Config = WebConfigurationManager.OpenWebConfiguration("/", web.Site.WebApplication.Name);
                }

                // ConfigurationSection _ConfigSection = _Config.GetSection("EvershedsSettings/EvershedsBulletinBoard");

                ConfigurationSection _CredentialSection = _Config.GetSection("EvershedsSettings/Email");
                DataSet _DsCredentials = new DataSet();
                _DsCredentials.ReadXml(new StringReader(_CredentialSection.SectionInformation.GetRawXml()));
                foreach (DataRow _Dr in _DsCredentials.Tables[0].Rows)
                {
                    switch (_Dr["key"].ToString().ToLower())
                    {
                        case "smtpserver":
                            smtpServer = _Dr["Value"].ToString();
                            break;

                    }
                }

                //SPWebApplication webApplication = this.Parent as SPWebApplication;
                //System.Configuration.ConfigurationSettings config = WebConfigurationManager.OpenWebConfiguration("/", webApplication.Name);
                //String appValue = config.AppSettings.Settings["appSettingKey"].Value;
                Debug.WriteLine("Smpt server " + smtpServer);

                EmailHelper.SendEmail(email, smtpServer);
                //EmailHelper.SendEmail(email);

                //Debug
                trc.LogInfo("Sent item rec'd email.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Knowledge Items] Exception setting event handler: " + ex.Message);
            }

            //Cleanup
            trc.Dispose();

        }

        private int CheckForFile(string attachmentFileName, SPFileCollection targetFiles)
        {
            //Boolean fileExists = false;
            int counter = 0;
            string ext = Path.GetExtension(attachmentFileName);

            attachmentFileName = attachmentFileName.Replace(ext, "");
            Debug.WriteLine("Searcing for " + attachmentFileName);
            foreach (SPFile file in targetFiles)
            {

                Debug.WriteLine(file.Name);
                if (file.Name.Contains(attachmentFileName))
                {
                    // fileExists = true;
                    Debug.WriteLine("Found file " + counter);
                    counter++;

                }


            }

            return counter;
        }

        private void CheckForFile(SPWeb parentWeb)
        {
            throw new NotImplementedException();
        }

        private string shortenFileName(string attachmentFileName)
        {
            Debug.WriteLine("File leng " + attachmentFileName);
            string str_Filename = string.Empty;
            string str_extension = Path.GetExtension(attachmentFileName);
            int int_amount_to_shorten = (attachmentFileName.Length - 128) + str_extension.Length + 1;
            str_Filename = string.Format("{0}{1}", attachmentFileName.Substring(0, attachmentFileName.Length - int_amount_to_shorten), str_extension);

            Debug.WriteLine("File length new " + str_Filename.Length);
            return str_Filename;



        }
        /// <summary>
        /// Shortens any urls that are over 260 chars
        /// restriction by sharepoin that urls are not to be over 260 chars
        /// </summary>
        /// <param name="fileURL">input url</param>
        /// <returns>cleaned up url</returns>
        private string shorten(string fileURL)
        {
            string str_shortened = string.Empty;
            Debug.WriteLine("Old url " + fileURL);



            string[] ary_input = fileURL.Split('/');
            string str_extension = Path.GetExtension(ary_input[ary_input.Length]);
            int int_amount_to_shorten = (ary_input.Length - fileURL.Length) - 260 + str_extension.Length;


            string filename = string.Format("{0}{1)", ary_input[ary_input.Length].Substring(0, int_amount_to_shorten), str_extension);
            str_shortened = fileURL.Replace(ary_input[ary_input.Length], filename);

            Debug.WriteLine("new url " + str_shortened.Length);
            return str_shortened;
        }

    }
}
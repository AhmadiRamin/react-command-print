﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Eversheds.Common.Config;
using Eversheds.Common.Web.Controls;
using Eversheds.Common.Log;
using Eversheds.Common.Email;
using Eversheds.Common.SharePoint;
using Eversheds.SharePoint.KnowledgeSubmissions.WebPartPages;

namespace Eversheds.SharePoint.KnowledgeSubmissions.Layouts.Eversheds
{
    public partial class KnowSubRej : LayoutsPageBase
    {


        private SPWeb _srcWeb;
        private SPFile _srcFile;
        //private SPList srcList = null;
        private string _fromEmail;

        private SPListItem srcItem = null;
        private string refCode = string.Empty;
        private SPList lstRemoveEmails = null;
        private string srcWebURL = string.Empty;

        #region Methods

        #region Overrides

        /// <summary>
        /// Override for OnInit event
        /// </summary>
        /// <param name="e">Event arguments</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            SPSite site = null;
            SPList srcList = null;
            

            try
            {

                //Process the querystring
                using (site = new SPSite(SPContext.Current.Web.Url))
                {
                    using (_srcWeb = site.OpenWeb())
                    {
                        srcList = _srcWeb.Lists[new Guid(Context.Request["List"])];
                        srcItem = srcList.GetItemById(int.Parse(Context.Request["ID"]));
                        _srcFile = _srcWeb.GetFile(srcItem.Url);
                        refCode = srcItem["Reference Code"].ToString();
                        srcWebURL = _srcWeb.Url;
                        lstRemoveEmails = srcList;
                        LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item] Found ref code at beining" + refCode);
                    }
                }

            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item1] Exception setting SP objects: " + ex.Message);
                Response.Redirect(Web.Url + "/KnowledgeItemsList");
            }

            //Check if this is an EML file
            if (_srcFile.Item.Name.ToLower().EndsWith(".eml"))
            {
                PreventEmailRejection();
            }


            //Set Email To value
            string emailTo = null;

            try
            {
                emailTo = srcItem["E-Mail From"].ToString();
            }
            catch { }

            if (string.IsNullOrEmpty(emailTo))
                To.Text = "[[ ENTER USERS EMAIL ADDRESS HERE ]]";
            else
            {
                string[] splitEmail = emailTo.Split(new char[] { '<' });
                string toEmail = splitEmail[1];
                toEmail = toEmail.Remove(toEmail.Length - 1, 1);

                To.Text = toEmail;
            }

            //Set email defaults
            SPItem defaultSettings = null;

            try
            {
                defaultSettings = SPListHelper.GetListItem(_srcWeb.Lists["Knowledge Mail Settings"], "Reject Item");
                Subject.Text = defaultSettings["Subject"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());
                Subject.Text = Subject.Text.Replace("[[REFCODE]]", srcItem["Reference Code"].ToString());
                //--TO DO - Need to replace the [[REFCODE]] section in the auto generated email body
                Body.Text = defaultSettings["Body"].ToString();
                _fromEmail = defaultSettings["From Address"].ToString();
            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item2] Exception setting email defaults: " + ex.Message);
            }


            //Config Controls
            SendMailCheck.PreRender += new EventHandler(SendMailCheck_PreRender);
            btnReject.Click += new EventHandler(btnReject_Click);
            btnCancelReject.Click += new EventHandler(btnCancelReject_Click);

            //Cleanup
            _srcWeb.Dispose();
            srcList = null;
            srcItem = null;
        }

        #endregion

        #region EventHandlers

        void SendMailCheck_PreRender(object sender, EventArgs e)
        {
            
            RequiredFieldValidatorBody.Enabled = SendMailCheck.Checked;
            RequiredFieldValidatorCc.Enabled = SendMailCheck.Checked;
            RequiredFieldValidatorSubject.Enabled = SendMailCheck.Checked;
            RequiredFieldValidatorTo.Enabled = SendMailCheck.Checked;
            RegularExpressionValidatorCcAddress.Enabled = SendMailCheck.Checked;
            RegularExpressionValidatorToAddress.Enabled = SendMailCheck.Checked;
        }

        void btnCancelReject_Click(object sender, EventArgs e)
        {
            string script;

            //Popup Message
            script = ("<SCRIPT language=\"VBScript\">\r\n");
            script += ("window.alert \"Rejection of item cancelled.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
            string redirect = srcWebURL + "/" + "KnowledgeItemsList";
            Response.Redirect(redirect);
            //Redirect
            script = ("<SCRIPT language=\"JavaScript\">\r\n");
            script += ("javascript:history.back();\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
        }

        void btnReject_Click(object sender, EventArgs e)
        {

            if (SendMailCheck.Checked == true)
            {
                try
                {
                    //Create Email
                    MailMessage email = new MailMessage(_fromEmail, To.Text, Subject.Text, Body.Text);

                    string strCCMail = Cc.Text;
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "CCEmals " + Cc.Text);

                    if (Cc.Text != "")
                    {
                        MailAddress ccAddres = new MailAddress(Cc.Text);
                        email.CC.Add(ccAddres);
                        // Send the email
                    }
                    //if (strCCMail.Contains(";"))
                    //{
                    //    string[] CCarray = strCCMail.Split(';');
                    //    for (int i = 0; i < CCarray.Length; i++)
                    //    {
                    //        // MailAddress ccAddres = new MailAddress(CCarray[i]);
                    //        // email.CC.Add(ccAddres);


                    //        LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "CCEmails " + CCarray[i].ToString());
                    //    }
                    //}


                    email.IsBodyHtml = true;

                    // Send the email
                    EmailHelper.SendEmail(email);
                }
                catch (Exception ex)
                {
                    LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item] Exception sending reject email: " + ex.Message);
                }
            }

            try
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item] trying to move file to " + _srcWeb.Url + "/KnowledgeItemsListRejected");
                //Move File to RejectedItems
                //SPFileHelper.MoveSPFileToLibrary(_srcFile, _srcWeb, "Knowledge Items Rejected");

                _srcFile.MoveTo(_srcWeb.Url + "/KnowledgeItemsListRejected/" + _srcFile.Name, true);

            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item] Exception moving file: " + ex.Message);
            }

            try
            {



                string[] refcodeAry = refCode.Split('-');
                CheckForLast.checkAndMovelast(lstRemoveEmails, refcodeAry[0], srcWebURL);
            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Reject Knowledge Item] Error checking lastattachement: " + ex.Message);

            }


            string script;

            //Popup Message
            script = ("<SCRIPT language=\"VBScript\">\r\n");
            script += ("window.alert \"Item has been rejected.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);

            string redirect = srcWebURL + "/" + "KnowledgeItemsList";
            LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "Redirect URL : " + redirect);

            Response.Redirect(redirect);

            script = string.Empty;

            //Redirect
            script = ("<SCRIPT language=\"JavaScript\">\r\n");
            script += ("javascript:history.back();\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
        }

        #endregion

        #region Functions

        /// <summary>
        /// Prevent rejection of EML files and redirect to Knowledge Items list
        /// </summary>
        private void PreventEmailRejection()
        {
            //Popup Message
            string script = ("<SCRIPT language=\"VBScript\">\r\n");
            script += ("window.alert \"Rejection of item cancelled.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);

            //Redirect
            script = ("<SCRIPT language=\"JavaScript\">\r\n");
            script += ("javascript:history.back();\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
        }

        #endregion

        #endregion
    }
}

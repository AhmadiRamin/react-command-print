﻿using System;
using System.Net.Mail;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Eversheds.Common.Email;
using Eversheds.Common.SharePoint;
using System.Diagnostics;
using Eversheds.SharePoint.KnowledgeSubmissions.WebPartPages;

namespace Eversheds.SharePoint.KnowledgeSubmissions.Layouts.Eversheds
{
    public partial class KnowSubRel : LayoutsPageBase
    {
        #region Variables

        //  protected HtmlGenericControl processKnowledgeContainer = new HtmlGenericControl();

        private SPSite _site;
        private SPFile _srcFile;
        private string _contentType;
        private string _libraryName;
        private string _knowledgeItemUrl;
        private string _knowledgeImageUrl;
        private string _fromEmail;
        private string _toEmail;
        private string _subject;
        private string _body;

        private string refCode = string.Empty;
        private SPList lstRemoveEmails = null;
        private string srcWebURL = string.Empty;



        #endregion






        #region Methods

        #region Overrides

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            EnsureUpdatePanelFixups();

            try
            {
                ScriptManager sm = ScriptManager.GetCurrent(this.Page);

                if (sm == null)
                {
                    //create new ScriptManager and EnablePartialRendering
                    sm = new ScriptManager();
                    sm.EnablePartialRendering = true;
                    sm.EnableScriptLocalization = true;

                    // Fix problem with postbacks and form actions
                    Page.ClientScript.RegisterStartupScript(typeof(KnowSubRel), this.ID, "_spOriginalFormAction = document.forms[0].action;", true);

                    //tag:"form" att:"onsubmit" val:"return _spFormOnSubmitWrapper()" blocks async postbacks after the first one
                    //not calling "_spFormOnSubmitWrapper()" breaks all postbacks
                    //returning true all the time, somewhat defeats the purpose of the _spFormOnSubmitWrapper() which is to block repetitive postbacks, but it allows MS AJAX Extensions to work properly
                    //its a hack that hopefully has minimal effect
                    if (this.Page.Form != null)
                    {
                        string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
                        if (!string.IsNullOrEmpty(formOnSubmitAtt) && formOnSubmitAtt == "return _spFormOnSubmitWrapper();")
                        {
                            this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
                        }

                        //add the ScriptManager as the first control in the Page.Form
                        //I don't think this actually matters, but I did it to be consistent with how you are supposed to place the ScriptManager when used declaritevly
                        this.Controls.AddAt(0, sm);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Create script manger error {0}", ex.Message);
            }
            // this.Page.Controls.Add(siteTree);
            //Bind EventHandlers
            btnRelease.Command += new CommandEventHandler(btnRelease_Command);
            btnCancelRelease.Command += new CommandEventHandler(btnCancelRelease_Command);
            siteTree.SelectedNodeChanged += new EventHandler(siteTree_SelectedNodeChanged);


        }


        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            try
            {

                Debug.WriteLine("Adding pannel");

                // base.Controls.Add(siteTree);

                //   ControlCollection constrols = Page.Controls;

                //foreach (Control ctl in this.Page.Form.Controls)
                //{
                //    Debug.WriteLine(ctl.ID);
                //}
                //panel = (UpdatePanel)FindControl("newUpdatePanel");
                ////this.Controls.Add(panel);
                newUpdatePanel.UpdateMode = UpdatePanelUpdateMode.Conditional;
                //Debug.WriteLine("Added pannel, now adding tree");
                //   newUpdatePanel.ContentTemplateContainer.Controls.Add(panel);
                newUpdatePanel.ContentTemplateContainer.Controls.Add(confirmText);
                newUpdatePanel.ContentTemplateContainer.Controls.Add(btnCancelRelease);
                newUpdatePanel.ContentTemplateContainer.Controls.Add(btnRelease);
                newUpdatePanel.ContentTemplateContainer.Controls.Add(siteTree);

                // this.Page.Controls.Add(siteTree);
                //Bind EventHandlers
                btnRelease.Command += new CommandEventHandler(btnRelease_Command);
                btnCancelRelease.Command += new CommandEventHandler(btnCancelRelease_Command);
                siteTree.SelectedNodeChanged += new EventHandler(siteTree_SelectedNodeChanged);
                siteTree.TreeNodeExpanded += new TreeNodeEventHandler(siteTree_TreeNodeExpanded);
                siteTree.TreeNodeCollapsed += new TreeNodeEventHandler(siteTree_TreeNodeCollapsed);

                Debug.WriteLine("Done adding tree");


            }
            catch (Exception ex)
            {
                Debug.WriteLine("Added tree error" + ex.Message);
            }

        }

        void siteTree_TreeNodeCollapsed(object sender, TreeNodeEventArgs e)
        {
            Debug.WriteLine("Treenode collpased {0}", e.Node.Text);
            Debug.WriteLine("Treenode parent {0}", e.Node.Parent.Text);
            e.Node.Collapse();
            e.Node.ChildNodes.Clear();
            e.Node.PopulateOnDemand = true;
        }

        void siteTree_TreeNodeExpanded(object sender, TreeNodeEventArgs e)
        {
            //throw new Exception("The method or operation is not implemented.");
            //Process sub nodes
            //foreach (SPWeb subweb in rootWeb.GetSubwebsForCurrentUser())
            //{


            if (!e.Node.ImageUrl.Contains("folder.gif"))
            {
                SPWeb subweb = _site.OpenWeb(e.Node.Value.Replace(_site.Url, ""), false);
                foreach (SPWeb web in subweb.GetSubwebsForCurrentUser())
                {
                    try
                    {
                        ProcessSubWeb(e.Node.ChildNodes, web);
                    }
                    finally
                    {
                        // if (web != null && web != SPContext.Current.Web)
                        // web.Dispose();
                    }

                }        
            }
            //}

            //ProcessSubWeb(e.Node.ChildNodes,e.no
        }
        /// <summary>
        /// Override for OnLoad
        /// </summary>
        protected override void OnLoad(EventArgs e)
        {

            base.CreateChildControls();
            //Set indicator image
            indicator.ImageUrl = _knowledgeImageUrl;



            //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item]Started");
            Debug.WriteLine("new release item started");
            SPWeb srcWeb = null;
            SPList srcList = null;
            SPListItem srcItem = null;
            SPListItem defaultSettings = null;

            try
            {
                //Get the SPFile object
                _site = new SPSite(SPContext.Current.Web.Url);
                srcWeb = _site.OpenWeb();
                
                    srcList = srcWeb.Lists[new Guid(Context.Request["List"])];
                    srcItem = srcList.GetItemById(int.Parse(Context.Request["ID"]));
                    _srcFile = srcWeb.GetFile(srcItem.Url);


                    defaultSettings = SPListHelper.GetListItem(srcWeb.Lists["Knowledge Mail Settings"], "Release Item");
                    refCode = srcItem["Reference Code"].ToString();
                    Debug.WriteLine("Reference code " + refCode);
                    srcWebURL = srcWeb.Url;
                    lstRemoveEmails = srcList;
                              
                //Set Email defaults

            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered setting SP objects: " + ex.Message);
                Debug.WriteLine("Error Knowlewdge submissions getting default values" + ex.Message);
            }

            //Set email information
            try
            {
                _fromEmail = defaultSettings["From Address"].ToString();
                _subject = defaultSettings["Subject"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());
                _subject = _subject.Replace("[[REFCODE]]", srcItem["Reference Code"].ToString());
                _body = defaultSettings["Body"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error setting emails texts" + ex.Message);
            }

            //Get config parameters
            try
            {
                SPList paramList = srcWeb.Lists["Knowledge Parameters"];

                //Content Type
                SPListItem param = SPListHelper.GetListItem(paramList, "Release Content Type");
                _contentType = param["Value"].ToString();
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] set releaste coent type ");

                //Release Library name
                if (SPListHelper.GetListItem(paramList, "Release Library") != null)
                {
                    param = SPListHelper.GetListItem(paramList, "Release Library");
                    _libraryName = param["Value"].ToString();
                }
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] set library name ");

                //Submitted Items Url
                if (SPListHelper.GetListItem(paramList, "Submitted Items Library") != null)
                {
                    param = SPListHelper.GetListItem(paramList, "Submitted Items Library");
                    _knowledgeItemUrl = srcWeb.Url + "/" + param["Value"].ToString();
                }
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] set submitted libary ");

                //Release site image
                if (SPListHelper.GetListItem(paramList, "Release Site Image") != null)
                {
                    param = SPListHelper.GetListItem(paramList, "Release Site Image");
                    _knowledgeImageUrl = param["Value"].ToString();
                }
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] set relase imagep ");
            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered attempting to get config parameters: " + ex.Message);
                Debug.WriteLine("Error 2" + ex.Message + " " + ex.StackTrace);
            }


            //Check if this is an EML file
            if (_srcFile.Item.Name.ToLower().EndsWith(".eml"))
            {
                PreventEmailRelease();
            }

            string emailTo = string.Empty;

            try
            {
                if (srcItem["Item Author"] != null)
                {
                    emailTo = srcItem["Item Author"].ToString();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error 3" + ex.Message);
            }

            try
            {
                if (string.IsNullOrEmpty(emailTo))
                    _toEmail = "[[ ENTER USERS EMAIL ADDRESS HERE ]]";
                else
                {
                    string[] splitEmail = emailTo.Split(new char[] { '<' });
                    _toEmail = splitEmail[1];
                    _toEmail = _toEmail.Remove(_toEmail.Length - 1, 1);
                }

                //_fromEmail = defaultSettings["From Address"].ToString();
                //_subject = defaultSettings["Subject"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());
                //_subject = _subject.Replace("[[REFCODE]]", srcItem["Reference Code"].ToString());
                //_body = defaultSettings["Body"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());
            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Error setting emails: " + ex.Message);
                Debug.WriteLine("Error 4" + ex.Message);
            }

            //Perform the release
            if (!this.IsPostBack)
                BuildSiteTree();

            //Cleanup
            //srcWeb.Dispose();
            srcItem = null;
            srcList = null;

        }



        #endregion

        #region Event Handlers

        void btnCancelRelease_Command(object sender, CommandEventArgs e)
        {
            try
            {
                //Popup Message
                /*
                string script = ("<SCRIPT language=\"VBScript\">" + "\r\n");
                script += ("window.alert \"Item release cancelled.\"\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);
                */
                string script = string.Empty;
                string redirect = srcWebURL + "/" + "KnowledgeItemsList";
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "Redirect URL : " + redirect);

                Response.Redirect(redirect);
            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered cancelling release of item: " + ex.Message);
                Debug.WriteLine("Error 5" + ex.Message);
            }
        }

        void btnRelease_Command(object sender, CommandEventArgs e)
        {


            string folderURL = siteTree.SelectedNode.Value;

            ///folderURL = SPContext.Current.Site.Url + "/" + folderURL;

            Debug.WriteLine("Folder url" + folderURL);
            SPSite site = new SPSite(folderURL);
            SPWeb web = site.OpenWeb();
            Debug.WriteLine("Started to do release");
            //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Started button command" + _libraryName + web.Url);


            //Check if Knowledge library on site
            bool listExist = true;
            try
            {
                SPList lib = web.Lists[_libraryName];
                Submitter submitterRelease = new Submitter();
                submitterRelease.AddFieldToList(lib.Fields, "Submitter");
            }
            catch
            {
                listExist = false;
            }

            Debug.WriteLine("List exists " + listExist.ToString());
            if (listExist)
            {

                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Check knowledge library");
                // SPFileHelper.MoveSPFileToLibrary(_srcFile, web, _libraryName);
                Debug.WriteLine("Release Knowledge Library");
                //SPFolder
                SPFile destFile = null;

                try
                {

                    Debug.WriteLine("SPContgent " + SPContext.Current.Site.Url);
                    Debug.WriteLine("folder url" + folderURL);
                    Debug.WriteLine("SRC FILENAME " + _srcFile.Name);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("error with url " + ex.Message);
                }

                string ReleaseURL = folderURL + "/" + _srcFile.Name;
                string destWEBName = string.Empty;

                try
                {
                    using (SPSite fileSite = new SPSite(ReleaseURL))
                    {
                        using (SPWeb destWeb = fileSite.OpenWeb())
                        {
                            Debug.WriteLine("trying to copy file from" + _srcFile.Url + " to " + ReleaseURL);
                            byte[] srcFileByteArray = _srcFile.OpenBinary();
                            SPFolder destFolder = destWeb.GetFolder(folderURL);

                            SPFileCollection destCol = destFolder.Files;
                            destCol.Add(ReleaseURL, srcFileByteArray, true);

                            destFile = destWeb.GetFile(ReleaseURL);

                            SPListItem srcItem = _srcFile.Item.Web.GetListItem(_srcFile.Item.Web.Url + "/" + _srcFile.Url);
                            SPListItem tgtItem = destWeb.GetListItem(ReleaseURL);

                            SPFieldCollection fields = srcItem.Fields;


                            foreach (SPField field in fields)
                            {
                                if (field.ReadOnlyField == false && srcItem[field.Title] != null)
                                {
                                    try
                                    {

                                        tgtItem[field.Title] = srcItem[field.Title];

                                        tgtItem.SystemUpdate(false);
                                        Debug.WriteLine("Updated OK " + field.Title);
                                    }
                                    catch (Exception ex)
                                    {
                                        Debug.WriteLine("Error updating field tagging " + field.Title + " " + ex.Message);
                                    }
                                }

                            }



                            destWEBName = destWeb.Title;
                            Debug.WriteLine("Copied OK");


                            try
                            {
                                Debug.WriteLine("Deleting original");
                                _srcFile.Delete();

                                _srcFile.Update();
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine("Error deleting orignal file" + ex.Message);
                            }


                            try
                            {
                                destFile.Approve("Knowledge submissions");
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine("Knowledge submissions tnable to approve " + ex.Message);
                            }
                        }


                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error moving file " + ex.Message);
                }

                try
                {
                    Debug.WriteLine("setting email");
                    string[] refcodeAry = refCode.Split('-');
                    SPQuery query = new SPQuery();
                    //Create Email
                    _body = _body.Replace("[[RELEASESITENAME]]", destWEBName);
                    _body = _body.Replace("[[RELEASESITEURL]]", "<a href='" + ReleaseURL + "'>" + ReleaseURL + "</a>");

                    query.Query = "<Where><BeginsWith><FieldRef Name='Reference_x0020_Code' /><Value Type='Text'>" + refcodeAry[0] + "-000</Value></BeginsWith>   </Where>";
                    //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item]getting refnum for emailaddress: " + refcodeAry[0] + "-000");
                    Debug.WriteLine("SPQuery " + query.Query);
                    SPListItemCollection colItems = lstRemoveEmails.GetItems(query);
                    foreach (SPListItem item in colItems)
                    {
                        _toEmail = item["Item Author"].ToString();

                    }
                }
                catch (Exception ex)
                {
                    //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered trying to get email: " + ex.Message);
                    Debug.WriteLine("Emaile sp query 6" + ex.Message);
                }
                try
                {
                    Debug.WriteLine("Sending email");
                    MailMessage email = new MailMessage(_fromEmail, _toEmail, _subject, _body);
                    email.Subject = _subject;
                    email.Body = _body;
                    email.IsBodyHtml = true;

                    // Send the email
                    EmailHelper.SendEmail(email);
                    Debug.WriteLine("Done sending eail");

                }
                catch (Exception ex)
                {

                    Debug.WriteLine("Error sending mail " + ex.Message);
                }
                //Popup Message
                /*
                string script = ("<SCRIPT language=\"VBScript\">" + "\r\n");
                script += ("window.alert \"Item has been succesfully moved.\"\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);

                script = string.Empty;
                */
                //Redirect
                //script = ("<SCRIPT language=\"JavaScript\">" + "\r\n");
                //script += ("window.location='" + _knowledgeItemUrl + "'\r\n");
                //script += ("</SCRIPT>");
                //Context.Response.Write(script);






            }
            else
            {
                /*
                //Popup Message
                string errScript = ("<SCRIPT language=\"VBScript\">" + "\r\n");
                errScript += ("window.alert \"This site does not contain a " + _libraryName + " library.\"\r\n");
                errScript += ("</SCRIPT>");
                Context.Response.Write(errScript);
                */
                string errScript = string.Empty;
                Response.Redirect(_knowledgeItemUrl);
            }

            try
            {
                string[] refcodeAry = refCode.Split('-');
                CheckForLast.checkAndMovelast(lstRemoveEmails, refcodeAry[0], srcWebURL);
            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Reject Knowledge Item] Error checking lastattachement: " + ex.Message);
                Debug.WriteLine("Check for last error" + ex.Message);
            }
            //Cleanup
            string redirect = SPContext.Current.Web.Url + "/" + "KnowledgeItemsList";
            //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "Redirect URL : " + redirect);
            Response.Redirect(redirect);
            //site.Dispose();
            //web.Dispose();

        }

        /// <summary>
        /// SiteTree's SelectedNodeChanged event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void siteTree_SelectedNodeChanged(object sender, EventArgs e)
        {
            string folderURL = siteTree.SelectedNode.Value;
            //  folderURL = SPContext.Current.Site.Url + "/" +folderURL;
            confirmText.Text = "Please confirm you wish to release this item to the '" + folderURL + "' site:";
            confirm.Visible = true;
        }

        #endregion

        #region Functions

        /// <summary>
        /// Builds the site tree, making nodes selectable
        /// if they contain a "Knowledge" directory.
        /// </summary>
        private void BuildSiteTree()
        {
            //Check item to be published is of this content type
            if (_srcFile.Item["Content Type"].ToString() == _contentType)
            {
                //Get the root web of site collection
                SPWeb rootWeb = SPContext.Current.Site.RootWeb;

                try
                {
                    //Impersonate App pool acc
                    //using (HostingEnvironment.Impersonate())
                    //using (Identity impersonate = Identity.ImpersonateAdmin())
                    //{
                    SPSecurity.RunWithElevatedPrivileges(delegate ()
                    {
                        //Create Root Node
                        TreeNode rootNode = new TreeNode(rootWeb.Title, rootWeb.Url);

                        //If contains list, make root node selectable
                        if (SPWebHelper.WebContainsList(rootWeb, _libraryName))
                        {
                            rootNode.SelectAction = TreeNodeSelectAction.Select;
                            rootNode.ImageUrl = _knowledgeImageUrl;
                        }
                        else
                            rootNode.SelectAction = TreeNodeSelectAction.None;

                        rootNode.PopulateOnDemand = true;
                        //Add Root node
                        siteTree.Nodes.Add(rootNode);


                        //Process sub nodes
                        //foreach (SPWeb subweb in rootWeb.GetSubwebsForCurrentUser())
                        //{
                        //    ProcessSubWeb(siteTree.Nodes[0].ChildNodes, subweb);
                        //}

                        siteTree.CollapseAll();
                    });
                    //}
                }
                catch (Exception ex)
                {
                    //LogHelper.Add("KnowledgeSubmit", //LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception attempting to build site tree: " + ex.Message);
                    Debug.WriteLine("Error with tree" + ex.Message);
                }

            }
            else
            {
                //Popup Message
                /*
                string script = ("<SCRIPT language=\"VBScript\">\r\n");
                script += ("window.alert \"This document is not of the correct Content Type. Please ensure the item is tagged properly before releasing it.\"\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);
                */
                string redirect = srcWebURL + "/" + "KnowledgeItemsList";
                Response.Redirect(redirect);
            }


        }

        /// <summary>
        /// Add webs to the tree
        /// </summary>
        /// <param name="nodeCollection">Node collection to add web to</param>
        /// <param name="web">Web to be added</param>
        private void ProcessSubWeb(TreeNodeCollection nodeCollection, SPWeb web)
        {
            //using (HostingEnvironment.Impersonate())
            //using (Identity impersonate = Identity.ImpersonateAdmin())
            //{
            //   Debug.WriteLine("Building tree");
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                //Make new node
                TreeNode node = new TreeNode(web.Title, web.Url);

                //If node contains list, make it selectable


                if (SPWebHelper.WebContainsList(web, _libraryName))
                {
                    node.SelectAction = TreeNodeSelectAction.Select;
                    node.ImageUrl = _knowledgeImageUrl;
                    node.PopulateOnDemand = false;
                    BuildFolders(web, node);
                }
                else
                {
                    node.SelectAction = TreeNodeSelectAction.None;

                    //Add to collection
                    node.PopulateOnDemand = true;
                }

                nodeCollection.Add(node);

                ////Recurse to do all sub nodes
                //foreach (SPWeb subweb in web.GetSubwebsForCurrentUser())
                //    ProcessSubWeb(node.ChildNodes, subweb);
            });
            // }
        }


        private void BuildFolders(SPWeb web, TreeNode rootNode)
        {
            string _CorrectedLibraryPath = "Knowledge";
            string baseURL = web.Url;
            SPDocumentLibrary doclib = (SPDocumentLibrary)web.Lists[_CorrectedLibraryPath];

            SPQuery query = new SPQuery();

            //TreeView TreeView1 = new TreeView();
            SPFolder root = doclib.RootFolder;
            TreeNode node = new TreeNode();
            node = Utility.GetFolderNode(node, root, baseURL);
            node.Text = doclib.Title;
            node.Value = web.Url + "/" + doclib.Title;
            Debug.WriteLine(node.Value);
            //node.NavigateUrl = doclib.DefaultViewUrl;
            long size = Utility.GetFolderSize(root) / 1024;
            long numFiles = Utility.GetNumberOfFilesInFolder(root);
            node.ToolTip = "Size:" + size.ToString() + " KBs " + " Files:" + numFiles.ToString();
            node.ImageUrl = baseURL + "/_layouts/15/images/folder.gif";
            //TreeView1.Nodes.Add(node);
            node.SelectAction = TreeNodeSelectAction.Select;
            node.PopulateOnDemand = false;
            rootNode.ChildNodes.Add(node);

            // TreeView1.ShowLines = true;
            //  TreeView1.EnableViewState = false;


        }
        /// <summary>
        /// Show message saying unable to release email and redirect back to Knowledge Items
        /// </summary>
        private void PreventEmailRelease()
        {
            //Popup Message
            /*
            string script = ("<SCRIPT language=\"VBScript\">\r\n");
            script += ("window.alert \"Not able to release .EML file.  Please ensure any knowledge item is a document that exists in DM before releasing.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
            */
            string redirect = srcWebURL + "/" + "KnowledgeItemsList";
            Response.Redirect(redirect);
        }

        #endregion

        #endregion

        #region AJAXFIXES
        private void EnsureUpdatePanelFixups()
        {

            if (this.Page.Form != null)
            {
                string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
                if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();")
                {
                    this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
                }

                Debug.WriteLine("Submitter fix up ran");
            }
            ScriptManager.RegisterStartupScript(this, typeof(KnowSubRel), "UpdatePanelFixup", "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);

        }
        #endregion
    }
}

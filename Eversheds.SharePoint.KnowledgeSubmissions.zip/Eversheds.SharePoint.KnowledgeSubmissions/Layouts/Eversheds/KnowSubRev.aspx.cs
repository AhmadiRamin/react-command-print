﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Eversheds.Common.Web.Controls;
using Eversheds.Common.Email;
using Eversheds.Common.Log;
using Eversheds.Common.SharePoint;
using System.Diagnostics;

namespace Eversheds.SharePoint.KnowledgeSubmissions.Layouts.Eversheds
{
    public partial class KnowSubRev : LayoutsPageBase
    {
        #region Variables


        private SPWeb _srcWeb;
        private SPFile _srcFile;
        private string _fromEmail;
        private SPListItem srcItem = null;
        private string status = string.Empty;
        private string srcWebURL = string.Empty;
        #endregion

        #region Methods

        #region Overrides

        /// <summary>
        /// Override for OnInit event
        /// </summary>
        /// <param name="e">Event arguments</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Process the querystring
            SPSite site = null;
            SPList srcList = null;

            SPListItem defaultSettings = null;
            SPListItem libraryUrl = null;

            try
            {

                using (site = new SPSite(SPContext.Current.Web.Url))
                {
                    using (_srcWeb = site.OpenWeb())
                    {

                        srcList = _srcWeb.Lists[new Guid(Context.Request["List"])];
                        srcWebURL = _srcWeb.Url;

                        srcItem = srcList.GetItemById(int.Parse(Context.Request["ID"]));
                        _srcFile = _srcWeb.GetFile(srcItem.Url);
                        status = srcItem["Status"].ToString();
                        Debug.WriteLine("[Review Knowledge Item] status" + status);
                        defaultSettings = SPListHelper.GetListItem(_srcWeb.Lists["Knowledge Mail Settings"], "Review Item");
                        libraryUrl = SPListHelper.GetListItem(_srcWeb.Lists["Knowledge Parameters"], "Submitted Items Library");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[Review Knowledge Item] Exception setting SP Objects: " + ex.Message);
            }

            try
            {
                //To.Text = "[[ ENTER REVIEWER'S EMAIL ADDRESS HERE ]]";

                Debug.WriteLine("[Review Knowledge Item] got list" + srcItem["Reference Code"].ToString());
                string redirectUrl = _srcWeb.Url + "/" + libraryUrl["Value"].ToString(); ;


                //Get the reference number to apply against email and attachments
                SPList parameters = _srcWeb.Lists["Knowledge Parameters"];
                SPListItem refNo = SPListHelper.GetListItem(parameters, "Reference Code Counter");



                // int newRef = Convert.ToInt32(refNo["Value"].ToString()) + 1;

                string subjectText = defaultSettings["Subject"].ToString().Replace("[[NAME]]", srcItem["Name"].ToString());

                subjectText = subjectText.Replace("[[NAME]]", srcItem["Name"].ToString());
                Debug.WriteLine("Set tittle " + srcItem["Name"].ToString());
                subjectText = subjectText.Replace("[[REFCODE]]", srcItem["Reference Code"].ToString());

                Subject.Text = subjectText;

                Debug.WriteLine("[Review Knowledge Item] set subject list");
                string body = defaultSettings["Body"].ToString().Replace("[[DOCUMENT]]", "<a href='" + _srcWeb.Url + "/" + srcItem.Url + "'>" + srcItem.Url + "</a>");
                Body.Text = body.Replace("[[PROPERTIES]]", "<a href='" + redirectUrl + "/Forms/DispForm.aspx?ID=" + Context.Request["ID"] + "'>" + redirectUrl + "Forms/EditForm.aspx?ID=" + Context.Request["ID"] + "</a>");
                Debug.WriteLine("[Review Knowledge Item] set body list");
                _fromEmail = defaultSettings["From Address"].ToString();
                Debug.WriteLine("[Review Knowledge Item] set from list");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[Review Knowledge Item] Exception setting email params: " + ex.Message);
            }


            //Config Controls
            btnMail.Click += new EventHandler(btnMail_Click);
            btnCancel.Click += new EventHandler(btnCancel_Click);

            RequiredFieldValidatorBody.Enabled = true;
            RequiredFieldValidatorCc.Enabled = true;
            RequiredFieldValidatorSubject.Enabled = true;
            RequiredFieldValidatorTo.Enabled = true;
            RegularExpressionValidatorCcAddress.Enabled = true;
            RegularExpressionValidatorToAddress.Enabled = true;


            //Cleanup
            _srcWeb.Dispose();
            srcList = null;
            srcItem = null;
        }

        #endregion

        #region EventHandlers

        void btnCancel_Click(object sender, EventArgs e)
        {
            string script;

            _srcFile.Item["Status"] = status;
            _srcFile.Item.SystemUpdate();
            //modal window
            //Popup Message
            /*
            script = ("<SCRIPT language=\"VBScript\">\r\n");
            script += ("window.alert \"Review item cancelled.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
            */
            string redirect = srcWebURL + "/" + "KnowledgeItemsList";
            Response.Redirect(redirect);
            //Redirect
            script = ("<SCRIPT language=\"JavaScript\">\r\n");
            script += ("javascript:history.back();\r\n");
            script += ("</SCRIPT>");


            Context.Response.Write(script);
        }


        void btnMail_Click(object sender, EventArgs e)
        {
            try
            {
                //Create Email
                MailMessage email = new MailMessage(_fromEmail, To.Text, Subject.Text, Body.Text);


                email.IsBodyHtml = true;
                Debug.WriteLine("[Review Knowledge Item] trying to update item");
                _srcFile.Item["Status"] = "Sent for Review";
                _srcFile.Item.SystemUpdate();
                string strCCMail = Cc.Text;
                Debug.WriteLine("CCEmals " + Cc.Text);

                if (Cc.Text != "")
                {
                    Debug.WriteLine("If CCEmals " + Cc.Text);
                    MailAddress ccAddres = new MailAddress(Cc.Text);
                    email.CC.Add(ccAddres);
                    // Send the email
                }
                EmailHelper.SendEmail(email);

                //   string script;


                //                Response.Redirect(_srcWeb.Url + "/" + srcItem.ParentList.Title);
                //popup message
                //script = ("<script language=\"vbscript\">\r\n");
                //script += ("window.alert \"item review mail sent.\"\r\n");
                //script += ("</script>");
                //Context.Response.Write(script);
                //script = string.Empty;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("[Review Knowledge Item] Exception sending review email: " + ex.Message);
            }


            try
            {
                string redirect = srcWebURL + "/" + "KnowledgeItemsList";
                Debug.WriteLine("Redirect URL : " + redirect);

                Response.Redirect(redirect);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error : " + ex.Message);
            }

            //Redirect
            //script = ("<SCRIPT language=\"JavaScript\">\r\n");
            //script += ("javascript:history.back();\r\n");
            //script += ("</SCRIPT>");
            //Context.Response.Write(script);


        }

        #endregion

        #endregion  
    }
}

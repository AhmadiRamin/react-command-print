﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.ApplicationPages;
using Microsoft.SharePoint.Utilities;

using Eversheds.Common.Log;
using Eversheds.Common.SharePoint;
using Eversheds.Common.Web.Controls;


namespace Eversheds.SharePoint.KnowledgeSubmissions.Layouts.Eversheds
{
    public partial class KnowSubRes : LayoutsPageBase
    {
        #region Variables

        private SPSite _site;
        private SPFile _srcFile;
        private string _rejectedKnowledgeItemUrl;
        private string srcWebURL = string.Empty;
        #endregion

        #region Methods

        #region Overrides

        /// <summary>
        /// Override for OnLoad
        /// </summary>
        protected override void OnLoad(EventArgs e)
        {
            base.CreateChildControls();

            //Bind EventHandlers
            btnRestore.Command += new CommandEventHandler(btnRestore_Command);
            btnCancel.Command += new CommandEventHandler(btnCancel_Command);

            //Get the SPFile object
            SPWeb srcWeb = null;
            SPList srcList = null;
            SPListItem srcItem = null;

            try
            {
                using (_site = new SPSite(SPContext.Current.Web.Url))
                {
                    using (srcWeb = _site.OpenWeb())
                    {
                        srcList = srcWeb.Lists[new Guid(Context.Request["List"])];
                        srcItem = srcList.GetItemById(int.Parse(Context.Request["ID"]));
                        _srcFile = srcWeb.GetFile(srcItem.Url);
                        srcWebURL = srcWeb.Url;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Restore Knowledge Item] Exception sending restore email: " + ex.Message);
            }

            //Get Rejected Library url
            SPList parameters = srcWeb.Lists["Knowledge Parameters"];
            SPListItem rejectLib = SPListHelper.GetListItem(parameters, "Rejected Items Library URL");
            _rejectedKnowledgeItemUrl = srcWeb.Url + rejectLib["Value"].ToString();

            //Cleanup
            srcWeb.Dispose();
            srcList = null;
            srcItem = null;
        }

        #endregion

        #region Event Handlers

        void btnCancel_Command(object sender, CommandEventArgs e)
        {
            //Popup Message
            string script = ("<SCRIPT language=\"VBScript\">" + "\r\n");
            script += ("window.alert \"Item restore cancelled.\"\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);

            string redirect = srcWebURL + "/" + "KnowledgeItemsList";
            Response.Redirect(redirect);
            //Redirect
            script = ("<SCRIPT language=\"JavaScript\">" + "\r\n");
            script += ("javascript:history.back();\r\n");
            script += ("</SCRIPT>");
            Context.Response.Write(script);
        }

        void btnRestore_Command(object sender, CommandEventArgs e)
        {
            try
            {
                SPWeb web = _site.OpenWeb();

                SPFileHelper.MoveSPFileToLibrary(_srcFile, web, "KnowledgeItemsList");

                //Popup Message
                string script = ("<SCRIPT language=\"VBScript\">" + "\r\n");
                script += ("window.alert \"Item restored.\"\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);

                script = string.Empty;

                //Redirect
                script = ("<SCRIPT language=\"JavaScript\">" + "\r\n");
                script += ("javascript:history.back();\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);

                //Cleanup
                web.Dispose();
            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Restore Knowledge Item] Exception restoring file: " + ex.Message);
            }
        }

        #endregion

        #endregion

    }
}

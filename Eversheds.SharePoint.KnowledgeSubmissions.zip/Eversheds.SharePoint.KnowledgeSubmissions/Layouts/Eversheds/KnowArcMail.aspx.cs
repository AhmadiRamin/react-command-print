﻿using System;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Eversheds.Common.Log;
using System.Diagnostics;

namespace Eversheds.SharePoint.KnowledgeSubmissions.Layouts.Eversheds
{
    public partial class KnowArcMail : LayoutsPageBase
    {
        #region Variables

        private SPSite _site;
        private SPFile _srcFile;

        private string refCode = string.Empty;
        // private SPList lstRemoveEmails = null;
        private string srcWebURL = string.Empty;

        #endregion

        #region Methods

        #region Overrides

        /// <summary>
        /// Override for OnLoad
        /// </summary>
        protected override void OnLoad(EventArgs e)
        {
            base.CreateChildControls();

            //Set indicator image
            //indicator.ImageUrl = _knowledgeImageUrl;

            //Bind EventHandlers
 
            LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Release Knowledge Item]Started");
            SPWeb srcWeb = null;
            SPList srcList = null;
            SPListItem srcItem = null;


            try
            {
                //Get the SPFile object

                Debug.WriteLine("Begin archive");

                using (_site = new SPSite(SPContext.Current.Web.Url))
                {
                    using (srcWeb = _site.OpenWeb())
                    {
                        srcWeb.AllowUnsafeUpdates = true;
                        srcList = srcWeb.Lists[new Guid(Context.Request["List"])];
                        srcItem = srcList.GetItemById(int.Parse(Context.Request["ID"]));
                        _srcFile = srcWeb.GetFile(srcItem.Url);


                        srcItem["Status"] = "Archive";
                        srcItem.Update();
                        Debug.WriteLine("Done update OK");

                        Response.Redirect(_site.Url + srcList.DefaultViewUrl);
                    }
                }

            }
            catch (Exception ex)
            {
                //LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered setting SP objects: " + ex.Message);
                Debug.WriteLine("Error updating archive " + ex.Message);

            }
        }



        #endregion

        #region Event Handlers

        void btnCancelRelease_Command(object sender, CommandEventArgs e)
        {
            try
            {
                //Popup Message
                string script = ("<SCRIPT language=\"VBScript\">" + "\r\n");
                script += ("window.alert \"Item release cancelled.\"\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);

                script = string.Empty;
                string redirect = srcWebURL + "/" + "KnowledgeItemsList";
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "Redirect URL : " + redirect);

                Response.Redirect(redirect);
                //Redirect
                script = ("<SCRIPT language=\"JavaScript\">" + "\r\n");
                script += ("javascript:history.back();\r\n");
                script += ("</SCRIPT>");
                Context.Response.Write(script);
            }
            catch (Exception ex)
            {
                LogHelper.Add("KnowledgeSubmit", LogHelper.LogMessageType.Error, "[Release Knowledge Item] Exception encountered cancelling release of item: " + ex.Message);
            }
        }

        void btnRelease_Command(object sender, CommandEventArgs e)
        {


        }


        #endregion

        #region Functions

        #endregion

        #endregion

    }
}

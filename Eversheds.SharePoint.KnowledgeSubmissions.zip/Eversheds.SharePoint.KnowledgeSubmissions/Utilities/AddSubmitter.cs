﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.Office.Server.Diagnostics;
using System.Diagnostics;

namespace Eversheds.SharePoint.KnowledgeSubmissions
{
    public class Submitter
    {

        public Boolean checkSubmitterField(SPList spListtoCheck, string fieldname )
        {

            
            
            return(spListtoCheck.Fields.ContainsField(fieldname));

            
        }

        public void AddCustomField(SPWeb web, string fieldType, string fieldName, bool isRequired, string defaultValue, string fieldGroup)
        {
            //Check if the field is there or not already
            if (!web.Fields.ContainsField(fieldName))
            {
                //Initializing a SPField instance
                SPField customField;

                //Creating a new filed
                customField = web.Fields.CreateNewField(fieldType, fieldName);

                //Assigning a group
                customField.Group = fieldGroup;

                //Sets this field is required field
                customField.Required = isRequired;

                //Assigning a default value
                customField.DefaultValue = defaultValue;

                //Adding the newly created field to SPweb
                web.Fields.Add(customField);
            }
        }

        public void AddFieldToList(SPFieldCollection colFields, string field)
        {


            if (!colFields.ContainsField(field))
            {
                Debug.WriteLine("Submitter field does not exist");
                try
                {
                    string FieldName = colFields.Add(field, SPFieldType.Text, false);
                    Debug.WriteLine(string.Format("Adding submitter {0} added field {1}", colFields.List.Title, FieldName));
                    //SPField oField = colFields.GetField(FieldName);
                    //SPView oView = colFields.List.DefaultView;
                    //SPViewFieldCollection colViewFields = oView.ViewFields;
                    //colViewFields.Add(oField);
                    //oView.Update();

                    //colFields.List.Update();

                    SPField oField = colFields.GetField(FieldName);
                    SPFieldLink oFieldLink = new SPFieldLink(oField);




                    SPContentType ct = colFields.Web.Lists[colFields.List.ID].ContentTypes["Eversheds Document"];
                    if (!ct.Fields.ContainsField(field))
                    {

                        ct.FieldLinks.Add(oFieldLink);
                        //ct.Fields.Add(oField);
                        ct.Update(false);
                        Debug.WriteLine(string.Format("Updted content type submitter {0} added field {1}", ct.Name, FieldName));
                    }




                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error adding submitter field");
                    PortalLog.LogString("Exception - {0} - {1} - {2}", "Knowledge submissions AddFieldToList", ex.Message, ex.StackTrace);


                }
            }
            else
            {
                Debug.WriteLine("Submitter field already exists "  + colFields.Web.Url);
            }
        }
    }
}

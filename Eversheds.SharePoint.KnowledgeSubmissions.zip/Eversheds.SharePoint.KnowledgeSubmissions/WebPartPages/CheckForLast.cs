﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using Eversheds.Common.Config;
using Eversheds.Common.Web.Controls;
using Eversheds.Common.Log;
using Eversheds.Common.Email;
using Eversheds.Common.SharePoint;
using System.Diagnostics;

namespace Eversheds.SharePoint.KnowledgeSubmissions.WebPartPages
{
    public class CheckForLast
    {

        public static void checkAndMovelast(SPList list, string refNum, string url)
        {

            try
            {
                Debug.WriteLine("[Check for last] item" + refNum);


                int counter = 0;
                Debug.WriteLine("[Checking for last] Countning " + list.Title);
                try
                {
                    SPQuery queryCount = new SPQuery();
                    queryCount.Query = "<Where><BeginsWith><FieldRef Name='Reference_x0020_Code' /><Value Type='Text'>" + refNum + "-</Value></BeginsWith>   </Where>";
                    SPListItemCollection colCount = list.GetItems(queryCount);
                    counter = colCount.Count;


                    Debug.WriteLine("[Checking for last] Found " + counter);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Check mnove to last error1 " + ex.Message);
                }




                try
                {
                    if (counter == 1)
                    {
                        SPQuery query = new SPQuery();
                        query.Query = "<Where>      <Eq>         <FieldRef Name='Reference_x0020_Code' />         <Value Type='Text'>" + refNum + "-000</Value>      </Eq>   </Where>";

                        SPListItemCollection colItems = list.GetItems(query);

                        foreach (SPListItem oItem in colItems)
                        {
                            string url_to_move = url + "/" + list.RootFolder.Url + "/KnowledgeMails/" + oItem.Name;
                            // SPFile file_to_Move = itemtoMove.File;
                            Debug.WriteLine("[Checking for last] trying to move " + url_to_move);
                            // itemtoMove.File.MoveTo(url_to_move, true);
                            oItem.File.MoveTo(url_to_move, true);
                        }

                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("[Checking for last] Move faild " + ex.Message);
                }

            }
            catch (Exception ex)
            {

                Debug.WriteLine("[Reject Knowledge Item class] Error checking class: " + ex.Message);
            }

        }
    }
}
